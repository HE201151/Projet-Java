package Controleur;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JButton;

import Model.Case;
import Model.Joueur;

public class Controleur {
	Joueur joueur1 ;
	Joueur joueur2;
	
	public Controleur(){
		joueur1 = new Joueur();
		joueur2 = new Joueur();
	}
	
	public void placerBateau(int coordonee, int selection,JButton[][] maGrille, int alignement){
		

		joueur1.placerBateau(coordonee, selection, alignement, maGrille);
		//if(caseCorrecte){
		//	((Component) e.getSource()).setBackground(Color.BLUE);
		//}
	}	
	
	
	public void attaquer(int coordonee, ActionEvent e, int numJoueur){
		boolean bateauTouche;
		if (numJoueur==1){
			bateauTouche=joueur1.bateauTouche(coordonee);
			if(bateauTouche){
				((Component) e.getSource()).setBackground(Color.RED);
			}
			else ((Component) e.getSource()).setBackground(Color.DARK_GRAY);
		}
		
		if (numJoueur==0){
			bateauTouche=joueur2.bateauTouche(coordonee);
			if(bateauTouche){
				((Component) e.getSource()).setBackground(Color.RED);
			}
			else ((Component) e.getSource()).setBackground(Color.DARK_GRAY);
		}
	}
	
	public void caseOccupee(JButton bouton, int i, int j, int numJoueur){
		boolean libre = true;
		Case position = new Case(j,i);
		
		if (numJoueur==2){
			libre=joueur2.caseLibre(position);
		}
		if (numJoueur==1){
			libre=joueur1.caseLibre(position);
		}
		if(!libre){
			bouton.setBackground(Color.BLUE);
		}
		
		
	}
	
	
	public void resetAction(JButton[][] maGrille){
		int i,j;
		joueur1.reset();
		for(i=0;i<=9;i++){
			for(j=0;j<=9;j++){
				maGrille[i][j].setBackground(Color.WHITE);
			}
		}
	}
}

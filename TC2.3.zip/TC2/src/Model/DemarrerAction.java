package Model;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import View.FenetreAccueil;
import View.ViewPlacement;

public class DemarrerAction extends AbstractAction {
	private FenetreAccueil fenetre;
	private ToucheCoule tc;
	
	public DemarrerAction(FenetreAccueil fenetre, String texte, ToucheCoule tc){
		super(texte);	
		this.tc = tc;
		
		this.fenetre = fenetre;
	}
	
	public void actionPerformed(ActionEvent e) { 
		ViewPlacement frame = new ViewPlacement(tc);
		frame.setVisible(true);
		fenetre.dispose(); 
		
	} 
}
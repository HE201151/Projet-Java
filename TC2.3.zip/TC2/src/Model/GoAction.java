package Model;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import View.ViewJeu;
import View.ViewPlacement;

public class GoAction extends AbstractAction {
	private ViewPlacement fenetre;
	private ToucheCoule tc;
	
	public GoAction(ViewPlacement fenetre, String texte,ToucheCoule tc){
		super(texte);		
		this.tc =tc;
		this.fenetre = fenetre;
	}
	
	public void actionPerformed(ActionEvent e) { 
		ViewJeu frame = new ViewJeu(tc);
		frame.setVisible(true);
		fenetre.dispose(); 
	} 
}
package View;


import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.GridLayout;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import Model.AProposAction;
import Model.DemarrerAction;
import Model.QuitterAction;
import Model.RegleAction;
import Model.ToucheCoule;

public class FenetreAccueil extends JFrame {
	
	private ToucheCoule tc;
	
	public FenetreAccueil(ToucheCoule tc){
		this.tc=tc;
		//super();
		build();
	}

	private void build(){
		
		setTitle("ToucheCoule"); //On donne un titre � l'application
		setSize(700,500); //On donne une taille � notre fen�tre
		setLocationRelativeTo(null); //On centre la fen�tre sur l'�cran
		setResizable(true); //On interdit la redimensionnement de la fen�tre
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //On dit � l'application de se fermer lors du clic sur la croix
		setContentPane(buildContentPane());
		
		JMenuBar menuBar = new JMenuBar();

		JMenu menu1 = new JMenu("ToucheCoule");
		JMenuItem demarrer = new JMenuItem(new DemarrerAction(this, "D�marrer", tc));
		menu1.add(demarrer);
		
		JMenuItem quitter = new JMenuItem(new QuitterAction(this, "Quitter"));
		menu1.add(quitter);
		menuBar.add(menu1);

		JMenu menu2 = new JMenu("R�gles");
		JMenuItem regle = new JMenuItem(new RegleAction(this, "R�gles"));
		menu2.add(regle);
		menuBar.add(menu2);
		
		JMenu menu3 = new JMenu("?");
		JMenuItem aPropos = new JMenuItem(new AProposAction(this, "A propos"));
		menu3.add(aPropos);
		menuBar.add(menu3);
		
		setJMenuBar(menuBar);
		
	}

	/**
	 * Create the frame.
	 */
	private JPanel buildContentPane(){

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(3, 1, 0, 0));
		
		
		
		JLabel lblTouchecoule = new JLabel("Touche-Coule");
		lblTouchecoule.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblTouchecoule);
		
		JButton demarrer = new JButton(new DemarrerAction(this, "D�marrer", tc));
		panel.add(demarrer);
		
		JButton quitter = new JButton(new QuitterAction(this, "Quitter"));
		panel.add(quitter);
		
		return panel;
	}

}
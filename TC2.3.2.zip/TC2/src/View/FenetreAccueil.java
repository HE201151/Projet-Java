package View;
/*
 *Projet Java Janvier 2014
 *@author Blan Romain et Vogeleer Martin
 */

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.SwingConstants;

import java.awt.GridLayout;

import Model.AProposAction;
import Model.DemarrerAction;
import Model.QuitterAction;
import Model.RegleAction;
import Model.ToucheCoule;
/*
 * Classe qui permet de voir une fen�tre d'acceuil.
 */
public class FenetreAccueil extends JFrame {	
	private ToucheCoule tc;
	
	/*
	 * Instance qui cr�e la JFrame d'acceuil.
	 * @param tc Base de donn�es.
	 */
	public FenetreAccueil(ToucheCoule tc){
		this.tc=tc;
		build();
	}

	/*
	 * M�thode qui cr�e la JFrame et son menu.
	 */
	private void build(){		
		//Partie Frame
		setTitle("ToucheCoule");
		setSize(700,500);
		setLocationRelativeTo(null);
		setResizable(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Ferme lors du clic sur la croix
		setContentPane(buildContentPane());
		
		//Partie menu
		JMenuBar menuBar = new JMenuBar();
		//Menu1
		JMenu menu1 = new JMenu("ToucheCoule");
		JMenuItem demarrer = new JMenuItem(new DemarrerAction(this, "D�marrer", tc));
		menu1.add(demarrer);
		JMenuItem bouttonQuitter = new JMenuItem(new QuitterAction(this, "Quitter"));
		menu1.add(bouttonQuitter);
		menuBar.add(menu1);
		//Menu2
		JMenu menu2 = new JMenu("R�gles");
		JMenuItem bouttonRegle = new JMenuItem(new RegleAction(this, "R�gles"));
		menu2.add(bouttonRegle);
		menuBar.add(menu2);
		//Menu3
		JMenu menu3 = new JMenu("?");
		JMenuItem bouttonAPropos = new JMenuItem(new AProposAction(this, "A propos"));
		menu3.add(bouttonAPropos);
		menuBar.add(menu3);
		
		setJMenuBar(menuBar);		
	}

	/*
	 * M�thode qui construit le panel et ses composant.
	 * @return retourne le panel
	 */
	private JPanel buildContentPane(){
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(3, 1, 0, 0));		
		
		//Partie composant
		JLabel label = new JLabel("Touche-Coule");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(label);		
		JButton boutonDemarrer = new JButton(new DemarrerAction(this, "D�marrer", tc));
		panel.add(boutonDemarrer);		
		JButton bouttonQuitter = new JButton(new QuitterAction(this, "Quitter"));
		panel.add(bouttonQuitter);
		
		return panel;
	}
}
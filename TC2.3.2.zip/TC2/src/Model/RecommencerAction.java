package Model;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import View.FenetreAccueil;
import View.ViewFinDuJeu;
import View.ViewPlacement;

public class RecommencerAction extends AbstractAction {
	
	private ViewFinDuJeu fenetre2;
	private ToucheCoule tc;
	

	
	public RecommencerAction(ViewFinDuJeu fenetre2, String texte, ToucheCoule tc) {
		super(texte);	
		this.tc = tc;
		
		this.fenetre2 = fenetre2;
		tc.getControleur().recommencer();
	}

	public void actionPerformed(ActionEvent e) { 
		ViewPlacement frame = new ViewPlacement(tc);
		frame.setVisible(true);
		fenetre2.dispose(); 
		
	} 

}
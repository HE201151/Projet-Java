package Model;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import View.FenetreAccueil;
import View.ViewFinDuJeu;
import View.ViewPlacement;

public class DemarrerAction extends AbstractAction {
	private FenetreAccueil fenetre;
	private ViewFinDuJeu fenetre2;
	private ToucheCoule tc;
	
	public DemarrerAction(FenetreAccueil fenetre, String texte, ToucheCoule tc){
		super(texte);	
		this.tc = tc;
		
		this.fenetre = fenetre;
	}
	
	public DemarrerAction(ViewFinDuJeu fenetre2, String texte, ToucheCoule tc) {
		super(texte);	
		this.tc = tc;
		
		this.fenetre2 = fenetre2;
	}

	public void actionPerformed(ActionEvent e) { 
		ViewPlacement frame = new ViewPlacement(tc);
		frame.setVisible(true);
		fenetre.dispose(); 
		
	} 

}
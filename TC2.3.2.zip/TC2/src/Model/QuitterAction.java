package Model;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

import View.FenetreAccueil;
import View.ViewFinDuJeu;

public class QuitterAction extends AbstractAction {
	private FenetreAccueil fenetre;
	private ViewFinDuJeu fenetre2;
	
	public QuitterAction(FenetreAccueil fenetre, String texte){
		super(texte);		
		this.fenetre = fenetre;
	}
	
	public QuitterAction(ViewFinDuJeu fenetre2, String texte){
		super(texte);		
		this.fenetre2 = fenetre2;
	}
	
	public void actionPerformed(ActionEvent e) { 
		System.exit(0);
	} 
}
package Model;


public class Bateau {
	int longueur;							// longueur du bateau en nombre de case
	Case[] coordonnees;						// cases que le bateau occupe
	
	

	
	public Bateau(int i){
		
		this.longueur=i+1;
		
		this.coordonnees= new Case[i+1];
		for(int j=0; j<=i;j++){
			//System.out.println(j);
			this.coordonnees[j]= new Case();
			this.coordonnees[j].X=10;
			
		}
		//System.out.println("fin");
		
	}
	
	public boolean estTouche(Case position){
		for(int i=0; i<=this.longueur-1;i++){
			if((this.coordonnees[i].X==position.X)&&(this.coordonnees[i].Y==position.Y)){
				this.coordonnees[i].X=10;
				this.coordonnees[i].Y=10;
				return true;
			}
		}
		return false;
	}
	
	
	
	

	
}